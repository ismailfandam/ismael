<?php
include("controllers/c_404.php");
$c_404 = new C_404();
$c_404->show_404();
?>
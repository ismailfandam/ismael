<?php
include("controllers/c_about.php");
$c_about = new C_about();
$c_about->show_about();
?>
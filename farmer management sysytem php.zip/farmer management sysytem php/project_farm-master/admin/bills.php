<?php
include("controllers/c_bills.php");
$c_bills = new C_bills();
$c_bills->show_bills();
?>
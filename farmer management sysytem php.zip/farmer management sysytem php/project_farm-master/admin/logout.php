<?php
include("controllers/c_logout.php");
$c_logout = new C_logout();
$c_logout->show_logout();
?>
<?php
include("controllers/c_informations.php");
$c_informations = new C_informations();
$c_informations->show_informations();
?>
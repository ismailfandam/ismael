<?php
include("controllers/c_favicon.php");
$c_favicon = new C_favicon();
$c_favicon->show_favicon();
?>
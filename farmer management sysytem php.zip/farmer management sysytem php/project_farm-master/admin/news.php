<?php
include("controllers/c_news.php");
$c_news = new C_news();
$c_news->show_news();
?>
<?php
include("controllers/c_products.php");
$c_products = new C_products();
$c_products->show_products();
?>
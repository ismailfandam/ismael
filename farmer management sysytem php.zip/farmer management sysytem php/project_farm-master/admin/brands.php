<?php
include("controllers/c_brands.php");
$c_brands = new C_brands();
$c_brands->show_brands();
?>
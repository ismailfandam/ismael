<?php
include("controllers/c_index.php");
$c_index = new C_index();
$c_index->show_index();
?>
<?php
include("controllers/c_comments.php");
$c_comments = new C_comments();
$c_comments->show_comments();
?>
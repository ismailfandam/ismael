<?php
include("controllers/c_login.php");
$c_login = new C_login();
$c_login->show_login();
?>
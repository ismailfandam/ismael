<?php
include("controllers/c_change_password.php");
$c_change_password = new C_change_password();
$c_change_password->show_change_password();
?>